<?php $__env->startSection('content'); ?>

    <div class="mb-0 border-0">

        <div class="p-0">
            <div class="text-center">
                <div class="mb-4">
                    <a href="<?php echo e(route('any', 'index')); ?>" class="auth-logo">
                        <img src="/images/logo-dark.png" alt="logo-dark" class="mx-auto" height="28" />
                    </a>
                </div>
            </div>
        </div>

        <div class="text-center pt-3">
            <div class="maintenance-img">
                <img src="/images/svg/confirmation-email.svg" height="72" alt="svg-logo">
            </div>
        </div>

        <div class="auth-title-section mb-3 text-center mt-2">
            <h3 class="text-dark fs-20 fw-medium mb-2">Email Confirmation</h3>
            <p class="text-muted fs-15">Please check your email for confirmation mail. <br>Click link in email to verification your account</p>
        </div>

        <div class="d-grid">
            <a href="#" class="btn btn-primary mt-3 me-1" type="submit">Resend Confirmation</a>
        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.auth', ['title' => 'Auth Confirm Mail'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coderthemes/Desktop/laravel-admin/kadso_laravel/resources/views/auth/confirm-mail.blade.php ENDPATH**/ ?>