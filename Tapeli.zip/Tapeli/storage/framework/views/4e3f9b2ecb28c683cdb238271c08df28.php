<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('layouts.partials/title-meta', ['title' => $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo $__env->make('layouts.partials/head-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body class="bg-white">

<div class="account-page">
    <div class="container-fluid p-0">
        <div class="row align-items-center g-0">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</div>
<!-- END wrapper -->

<!-- App js-->
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
<?php echo $__env->make('layouts.partials/vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH /home/coderthemes/Krushant/Market/Codecanyon/Bootstrap/Tapeli/Laravel/Tapeli_Laravel_v1.0.0/Tapeli/resources/views/layouts/auth.blade.php ENDPATH**/ ?>