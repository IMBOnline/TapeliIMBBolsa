<!-- bundle -->
<?php echo $__env->yieldContent('script'); ?>
<!-- App js -->
<?php echo $__env->yieldContent('script-bottom'); ?>
<?php /**PATH /home/coderthemes/Desktop/laravel-admin/kadso_laravel/resources/views/layouts/partials/vendor.blade.php ENDPATH**/ ?>