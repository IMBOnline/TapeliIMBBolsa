<?php $__env->startSection('body'); ?>
class="bg-color"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-0 border-0">
        <div class="p-0">
            <div class="text-center">
                <div class="mb-4">
                    <a href="<?php echo e(route('any', 'index')); ?>" class="auth-logo">
                        <img src="/images/logo-dark.png" alt="logo-dark" class="mx-auto" height="28" />
                    </a>
                </div>

                <div class="auth-title-section mb-3"> 
                    <h3 class="text-dark fs-20 fw-medium mb-2">Get's started</h3>
                    <p class="text-dark text-capitalize fs-14 mb-0">Please enter your details.</p>
                </div>
            </div>
        </div>

        <div class="pt-0">
            <form method="POST" action="<?php echo e(route('register')); ?>" class="my-4">
                <?php echo csrf_field(); ?>
                
                <div class="form-group mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input class="form-control" name="name" type="text" id="username" required value="test account" placeholder="Enter your Username">
                </div>

                <div class="form-group mb-3">
                    <label for="emailaddress" class="form-label">Email address</label>
                    <input class="form-control" type="email" id="emailaddress" required placeholder="Enter your email" value="test@test.com">
                </div>

                <div class="form-group mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input class="form-control" type="password" name="password" id="password" placeholder="Enter your password" value="password">
                </div>

                <div class="form-group d-flex mb-3">
                    <div class="col-12">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="checkbox-signin">
                            <label class="form-check-label" for="checkbox-signin">I agree to the <a href="#" class="text-primary fw-medium"> Terms and Conditions</a></label>
                        </div>
                    </div><!--end col-->
                </div>
                
                <div class="form-group mb-0 row">
                    <div class="col-12">
                        <div class="d-grid">
                            <button class="btn btn-primary" type="submit"> Register</button>
                        </div>
                    </div>
                </div>
            </form>
            <div class="text-center text-muted">
                <p class="mb-0">Already have an account ?<a class='text-primary ms-2 fw-medium' href="<?php echo e(route('second', [ 'auth' , 'login'])); ?>">Login here</a></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', ['title' => 'Register'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coderthemes/Desktop/laravel-admin/kadso_laravel/resources/views/auth/register.blade.php ENDPATH**/ ?>