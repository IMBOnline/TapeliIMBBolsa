<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('layouts.partials/title-meta', ['title' => $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo $__env->make('layouts.partials/head-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body <?php echo $__env->yieldContent('body'); ?>>

<?php echo $__env->yieldContent('content'); ?>

<!-- App js-->
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
<?php echo $__env->make('layouts.partials/vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\Users\pc comp\Desktop\kadso\resources\views/layouts/base.blade.php ENDPATH**/ ?>