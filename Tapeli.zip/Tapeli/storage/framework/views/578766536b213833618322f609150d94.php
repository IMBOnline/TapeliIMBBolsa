<?php $__env->startSection('content'); ?>    

<div class="text-center">
    <div class="mb-4 text-center">
        <a href="<?php echo e(route('any', 'index')); ?>" class="auth-logo">
            <img src="/images/logo-dark.png" alt="logo-dark" class="mx-auto" height="28"/>
        </a>
    </div>

    <div class="maintenance-img">
        <img src="/images/svg/503-error.svg" class="img-fluid" alt="coming-soon">
    </div>
    
    <div class="text-center">
        <h3 class="mt-4 fw-semibold text-black text-capitalize">Service unavailable</h3>
        <p class="text-muted">Temporary service outage. Please try again later.</p>
    </div>

    <a class="btn btn-primary mt-3 me-1" href="<?php echo e(route('any', 'index')); ?>">Back to Home</a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.error', ['title' => 'Error 503'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coderthemes/Krushant/Market/Codecanyon/Bootstrap/Tapeli/Laravel/Tapeli_Laravel_v1.0.0/Tapeli/resources/views/error/error-503.blade.php ENDPATH**/ ?>