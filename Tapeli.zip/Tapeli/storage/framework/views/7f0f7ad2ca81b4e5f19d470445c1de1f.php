<?php $__env->startSection('content'); ?>
    <div class="mb-0 border-0">
        <div class="p-0">
            <div class="text-center">
                <div class="mb-4">
                    <a href="<?php echo e(route('any', 'index')); ?>" class="auth-logo">
                        <img src="/images/logo-dark.png" alt="logo-dark" class="mx-auto" height="28" />
                    </a>
                </div>

                <div class="auth-title-section mb-3"> 
                    <h3 class="text-dark fs-20 fw-medium mb-2">Lock Screen</h3>
                    <p class="text-dark fs-14 mb-0">Welcome back! to access your account,<br> please enter your password.</p>
                </div>
            </div>
        </div>

        <div class="pt-0">
            <form action="index.html" class="my-4">
                <div class="form-group mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input class="form-control" type="password" id="password" required="" placeholder="Enter your password">
                </div>
                
                <div class="form-group mb-0 row">
                    <div class="col-12">
                        <div class="d-grid">
                            <button class="btn btn-primary" type="submit"> Unlock </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', ['title' => 'Lock Screen'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coderthemes/Desktop/laravel-admin/kadso_laravel/resources/views/auth/lockscreen.blade.php ENDPATH**/ ?>