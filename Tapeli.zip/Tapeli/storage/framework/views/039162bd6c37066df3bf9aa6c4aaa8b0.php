<?php $__env->startSection('content'); ?>
<div class="text-center">
    <div class="mb-4 text-center">
        <a href="<?php echo e(route('any', 'index')); ?>" class="auth-logo">
            <img src="/images/logo-dark.png" alt="logo-dark" class="mx-auto" height="28" />
        </a>
    </div>

    <div class="maintenance-img">
        <img src="/images/svg/coming-soon.svg" class="img-fluid" alt="coming-soon">
    </div>

    <div class="text-center">
        <h3 class="mt-4 fw-semibold text-dark text-capitalize">We are Coming Soon!!!</h3>
        <p class="text-muted">Get ready, we are under process of creating something really cool, <br> Our website will be available soon.</p>
    </div>

    <div class="row justify-content-center mt-5 mb-5">
        <div class="col-md-8 text-center">
            <div data-countdown="2026/12/31" class="counter-number"></div>
        </div> <!-- end col-->
    </div> <!-- end row-->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.error', ['title' => 'Coming Soon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coderthemes/Desktop/laravel-admin/kadso_laravel/resources/views/utility/coming-soon.blade.php ENDPATH**/ ?>