<!-- bundle -->
<?php echo $__env->yieldContent('script'); ?>
<!-- App js -->
<?php echo $__env->yieldContent('script-bottom'); ?>
<?php /**PATH /home/coderthemes/Krushant/Market/Codecanyon/Bootstrap/Tapeli/Laravel/Tapeli_Laravel_v1.0.0/Tapeli/resources/views/layouts/partials/vendor.blade.php ENDPATH**/ ?>