/*
Template Name: Tapeli - Responsive Laravel Admin Dashboard
Author: Zoyothemes
Version: 1.0.0
Website: https://zoyothemes.com/
File: Glightbox Js
*/

// 
// Glightbox Js
// 
import GLightbox from "glightbox";


var lightbox = GLightbox({ selector: ".image-popup", title: false });
var lightboxInlineIframe = GLightbox({
    selector: '.map-frame'
});