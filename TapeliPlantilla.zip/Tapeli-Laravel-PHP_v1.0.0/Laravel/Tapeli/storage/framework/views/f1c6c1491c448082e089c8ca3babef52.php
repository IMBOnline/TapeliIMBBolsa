<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['node_modules/swiper/swiper-bundle.min.css']); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- navbar section -->
    <nav class="navbar navbar-expand-lg fixed-top nav-light sticky" id="navbar">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('any', 'index')); ?>">
                <img src="/images/logo-dark.png" class="card-logo card-logo-light" alt="logo dark" height="24">
                <img src="/images/logo-light.png" class="card-logo card-logo-dark" alt="logo light" height="24">
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0" id="navbar-navlist">
                    <li class="nav-item">
                        <a class="nav-link" href="#home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#services">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#features">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#testimonials">Testimonials</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#faq">FAQ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#plans">Plans</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contact</a>
                    </li>
                </ul>
            </div><!-- end collapse -->
        </div><!-- end container -->
    </nav><!-- end navbar -->

    <!-- start hero section -->
    <section class="section pb-0 d-flex hero-section h-auto" id="home">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-sm-10 z-1 position-relative">
                    <div class="text-center mt-lg-5 pt-5">
                        <div class="caption-box text-center mb-50">
                            <h1 class="caption-title my-4 lh-base">Your Project to the Next Level with Kadso Admin
                                Dashboard</h1>
                            <p class="subtitle text-muted">Forge polished admin interfaces effortlessly with our go-to
                                solution. Simplify your workflow and elevate user experience seamlessly.</p>

                            <div class="d-flex gap-2 justify-content-center mt-4">
                                <a href="<?php echo e(route('any', 'index')); ?>" class="btn btn-primary">Live Preview <i
                                        class="mdi mdi-arrow-top-right align-middle text-white ms-1"></i></a>
                            </div>
                        </div>
                    </div>

                    <div class="main-dashboard mt-4 text-center rounded-top-3 pb-0">
                        <img src="/images/landing/dashboard.jpg" class="img-fluid rounded-top-3" alt="img">
                    </div>
                </div>
            </div><!-- end row -->
        </div><!-- end container -->
    </section>
    <!-- end hero section -->

    <!-- start client section -->
    <section class="section position-relative bg-white">
        <div class="container">
            <div class="row justify-content-center align-items-center text-center">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="trusted-title mb-3">
                        <h4 class="fs-20 text-muted">Trusted By World Best Companies</h4>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-2 col-md-2 col-6 text-center">
                    <img src="/images/landing/client/clients-logo-1.svg" alt="logo" class="img-fluid">
                </div>
                <div class="col-lg-2 col-md-2 col-6 text-center">
                    <img src="/images/landing/client/clients-logo-2.svg" alt="logo" class="img-fluid">
                </div>
                <div class="col-lg-2 col-md-2 col-6 text-center">
                    <img src="/images/landing/client/clients-logo-3.svg" alt="logo" class="img-fluid">
                </div>
                <div class="col-lg-2 col-md-2 col-6 text-center">
                    <img src="/images/landing/client/clients-logo-4.svg" alt="logo" class="img-fluid">
                </div>
                <div class="col-lg-2 col-md-2 col-6 text-center">
                    <img src="/images/landing/client/clients-logo-5.svg" alt="logo" class="img-fluid">
                </div>
            </div>
        </div>
    </section>
    <!-- end client section -->

    <!-- start services -->
    <section class="section bg-white service" id="services">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="text-center header-section mb-5">
                        <span class="text-uppercase fw-semibold text-primary">Services</span>
                        <h1 class="title-heading fw-semibold text-dark mb-3 mt-2">Crafting sleek and engaging websites
                            that captivate audiences and elevate brands.</h1>
                        <p class="text-muted fs-14 mb-0">We specialize in crafting fully customizable services tailored
                            precisely to meet your <br> distinct needs, Whether you're aiming to increase brand
                            awareness.</p>
                    </div>
                </div>
            </div>

            <div class="row g-3">
                <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                    <div class="p-3">
                        <div class="icon-box rounded-3 mb-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 16 16">
                                <path fill="#4a98f5"
                                      d="M16 0s-3.5-.4-6.7 2.8C7.7 4.3 6.4 6.3 5.4 8.1l-2.5-.6l-1.6 1.6l2.8 1.4c-.3.6-.4 1-.4 1l.8.8s.4-.2 1-.4l1.4 2.8l1.6-1.6l-.5-2.5c1.7-1 3.8-2.3 5.3-3.8C16.4 3.6 16 0 16 0m-3.2 4.8c-.4.4-1.1.4-1.6 0c-.4-.4-.4-1.1 0-1.6c.4-.4 1.1-.4 1.6 0c.4.4.4 1.1 0 1.6"/>
                                <path fill="#4a98f5"
                                      d="M4 14.2c-.8.8-2.6.4-2.6.4s-.4-1.8.4-2.6s1.5-.9 1.5-.9s-1.3-.3-2.1.6c-1.6 1.6-1 4.2-1 4.2s2.6.6 4.2-1c.9-.9.6-2.2.6-2.2s-.2.7-1 1.5"/>
                            </svg>
                        </div>
                        <div class="mb-3">
                            <h5 class="fs-20">All-in-one toolkit</h5>
                            <p class="text-muted my-3 fs-16">Empower your digital product business with an all-in-one
                                solution packed with innovative tools. From launch to success, access everything you
                                need.</p>
                        </div>
                        <div>
                            <a href="#" class="fs-13 fw-medium text-primary">Learn More <i
                                    class="mdi mdi-arrow-right fs-18 align-middle"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                    <div class="p-3">
                        <div class="icon-box rounded-3 mb-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="#4a98f5"
                                      d="M19 6H5a3 3 0 0 0-3 3v2.72L8.837 14h6.326L22 11.72V9a3 3 0 0 0-3-3"
                                      opacity="0.5"/>
                                <path fill="#4a98f5"
                                      d="M10 6V5h4v1h2V5a2.002 2.002 0 0 0-2-2h-4a2.002 2.002 0 0 0-2 2v1zm-1.163 8L2 11.72V18a3.003 3.003 0 0 0 3 3h14a3.003 3.003 0 0 0 3-3v-6.28L15.163 14z"/>
                            </svg>
                        </div>
                        <div class="mb-3">
                            <h5 class="fs-20">Business insights</h5>
                            <p class="text-muted my-3 fs-16">All the innovative tools you need to launch a lucrative
                                digital product business in one neat little package.</p>
                        </div>
                        <div>
                            <a href="#" class="fs-13 fw-medium text-primary">Learn More <i
                                    class="mdi mdi-arrow-right fs-18 align-middle"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                    <div class="p-3">
                        <div class="icon-box rounded-3 mb-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="#4a98f5" fill-rule="evenodd"
                                      d="M19 21.5H6A3.5 3.5 0 0 1 2.5 18V4.943c0-1.067 1.056-1.744 1.985-1.422c.133.046.263.113.387.202l.175.125a2.51 2.51 0 0 0 2.912-.005a3.52 3.52 0 0 1 4.082 0a2.51 2.51 0 0 0 2.912.005l.175-.125c.993-.71 2.372 0 2.372 1.22V12.5H21a.75.75 0 0 1 .75.75v5.5A2.75 2.75 0 0 1 19 21.5M17.75 14v4.75a1.25 1.25 0 0 0 2.5 0V14zM13.5 9.75a.75.75 0 0 0-.75-.75h-6a.75.75 0 0 0 0 1.5h6a.75.75 0 0 0 .75-.75m-1 3a.75.75 0 0 0-.75-.75h-5a.75.75 0 1 0 0 1.5h5a.75.75 0 0 0 .75-.75m.25 2.25a.75.75 0 1 1 0 1.5h-6a.75.75 0 0 1 0-1.5z"
                                      clip-rule="evenodd"/>
                            </svg>
                        </div>
                        <div class="mb-3">
                            <h5 class="fs-20">Invoicing</h5>
                            <p class="text-muted my-3 fs-16">Revolutionize your invoicing process with our streamlined
                                solution! Say goodbye to tedious manual invoicing and hello to beautifully.</p>
                        </div>
                        <div>
                            <a href="#" class="fs-13 fw-medium text-primary">Learn More <i
                                    class="mdi mdi-arrow-right fs-18 align-middle"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                    <div class="p-3">
                        <div class="icon-box rounded-3 mb-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="#4a98f5"
                                      d="M12 2C6.486 2 2 6.486 2 12v4.143C2 17.167 2.897 18 4 18h1a1 1 0 0 0 1-1v-5.143a1 1 0 0 0-1-1h-.908C4.648 6.987 7.978 4 12 4s7.352 2.987 7.908 6.857H19a1 1 0 0 0-1 1V18c0 1.103-.897 2-2 2h-2v-1h-4v3h6c2.206 0 4-1.794 4-4c1.103 0 2-.833 2-1.857V12c0-5.514-4.486-10-10-10"/>
                            </svg>
                        </div>
                        <div class="mb-3">
                            <h5 class="fs-20">Awesome Support</h5>
                            <p class="text-muted my-3 fs-16">Discover the unparalleled support experience you deserve
                                with our Awesome Support service. Our dedicated team is committed to your success.</p>
                        </div>
                        <div>
                            <a href="#" class="fs-13 fw-medium text-primary">Learn More <i
                                    class="mdi mdi-arrow-right fs-18 align-middle"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                    <div class="p-3">
                        <div class="icon-box rounded-3 mb-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="#4a98f5"
                                      d="M4 13h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1m0 8h6c.55 0 1-.45 1-1v-4c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v4c0 .55.45 1 1 1m10 0h6c.55 0 1-.45 1-1v-8c0-.55-.45-1-1-1h-6c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1M13 4v4c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1h-6c-.55 0-1 .45-1 1"/>
                            </svg>
                        </div>
                        <div class="mb-3">
                            <h5 class="fs-20">Smart Dashboards</h5>
                            <p class="text-muted my-3 fs-16">Welcome to the era of intelligent dashboards—your gateway
                                to streamlined data management. Our smart dashboards offer a user-friendly.</p>
                        </div>
                        <div>
                            <a href="#" class="fs-13 fw-medium text-primary">Learn More <i
                                    class="mdi mdi-arrow-right fs-18 align-middle"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-12 mt-4 pt-2">
                    <div class="p-3">
                        <div class="icon-box rounded-3 mb-3">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                                <path fill="#4a98f5"
                                      d="M16.519 16.501c.175-.136.334-.295.651-.612l3.957-3.958c.096-.095.052-.26-.075-.305a4.332 4.332 0 0 1-1.644-1.034a4.332 4.332 0 0 1-1.034-1.644c-.045-.127-.21-.171-.305-.075L14.11 12.83c-.317.317-.476.476-.612.651c-.161.207-.3.43-.412.666c-.095.2-.166.414-.308.84l-.184.55l-.292.875l-.273.82a.584.584 0 0 0 .738.738l.82-.273l.875-.292l.55-.184c.426-.142.64-.212.84-.308c.236-.113.46-.25.666-.412m5.849-5.809a2.163 2.163 0 1 0-3.06-3.059l-.126.128a.524.524 0 0 0-.148.465c.02.107.055.265.12.452c.13.375.376.867.839 1.33a3.5 3.5 0 0 0 1.33.839c.188.065.345.1.452.12a.525.525 0 0 0 .465-.148z"/>
                                <path fill="#4a98f5" fill-rule="evenodd"
                                      d="M4.172 3.172C3 4.343 3 6.229 3 10v4c0 3.771 0 5.657 1.172 6.828C5.343 22 7.229 22 11 22h2c3.771 0 5.657 0 6.828-1.172C20.981 19.676 21 17.832 21 14.18l-2.818 2.818c-.27.27-.491.491-.74.686a5.107 5.107 0 0 1-.944.583a8.163 8.163 0 0 1-.944.355l-2.312.771a2.083 2.083 0 0 1-2.635-2.635l.274-.82l.475-1.426l.021-.066c.121-.362.22-.658.356-.944c.16-.335.355-.651.583-.943c.195-.25.416-.47.686-.74l4.006-4.007L18.12 6.7l.127-.127A3.651 3.651 0 0 1 20.838 5.5c-.151-1.03-.444-1.763-1.01-2.328C18.657 2 16.771 2 13 2h-2C7.229 2 5.343 2 4.172 3.172M7.25 9A.75.75 0 0 1 8 8.25h6.5a.75.75 0 0 1 0 1.5H8A.75.75 0 0 1 7.25 9m0 4a.75.75 0 0 1 .75-.75h2.5a.75.75 0 0 1 0 1.5H8a.75.75 0 0 1-.75-.75m0 4a.75.75 0 0 1 .75-.75h1.5a.75.75 0 0 1 0 1.5H8a.75.75 0 0 1-.75-.75"
                                      clip-rule="evenodd"/>
                            </svg>
                        </div>
                        <div class="mb-3">
                            <h5 class="fs-20">Well Documented</h5>
                            <p class="text-muted my-3 fs-16">Explore our meticulously crafted digital product solution,
                                meticulously documented for your ease. Dive into a wealth of comprehensive.</p>
                        </div>
                        <div>
                            <a href="#" class="fs-13 fw-medium text-primary">Learn More <i
                                    class="mdi mdi-arrow-right fs-18 align-middle"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end service -->

    <!-- start feathers -->
    <section class="section bg-white bg-opacity-50" id="features">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="text-center header-section mb-5">
                        <span class="text-uppercase fw-semibold text-primary">Feature</span>
                        <h1 class="title-heading fw-semibold text-dark mb-3 mt-2">Our key feature</h1>
                        <p class="text-muted fs-14 mb-0">Our features that Streamlining Healthcare Management.</p>
                    </div>
                </div>
            </div>

            <div class="row align-items-center g-3">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="position-relative rounded-3">
                        <img src="/images/landing/features.jpg" alt="landing"
                             class="img-fluid rounded-3 shadow-sm">
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-12">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="d-flex features-key align-items-center p-3 rounded-3 shadow-sm">
                                <div class="text-center me-3">
                                    <i class="mdi mdi-check-circle text-primary fs-22"></i>
                                </div>
                                <div class="flex-1">
                                    <h4 class="mb-0 fs-18">Accurate information</h4>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="d-flex features-key align-items-center p-3 rounded-3 shadow-sm">
                                <div class="text-center me-3">
                                    <i class="mdi mdi-check-circle text-primary fs-22"></i>
                                </div>
                                <div class="flex-1">
                                    <h4 class="mb-0 fs-18">Appointment Management</h4>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="d-flex features-key align-items-center p-3 rounded-3 mt-3 shadow-sm">
                                <div class="text-center me-3">
                                    <i class="mdi mdi-check-circle text-primary fs-22"></i>
                                </div>
                                <div class="flex-1">
                                    <h4 class="mb-0 fs-18">Revenue Optimization</h4>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="d-flex features-key align-items-center p-3 rounded-3 mt-3 shadow-sm">
                                <div class="text-center me-3">
                                    <i class="mdi mdi-check-circle text-primary fs-22"></i>
                                </div>
                                <div class="flex-1">
                                    <h4 class="mb-0 fs-18">Inter-Team Collaboration</h4>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="d-flex features-key align-items-center p-3 rounded-3 mt-3 shadow-sm">
                                <div class="text-center me-3">
                                    <i class="mdi mdi-check-circle text-primary fs-22"></i>
                                </div>
                                <div class="flex-1">
                                    <h4 class="mb-0 fs-18">Interface customization</h4>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="d-flex features-key align-items-center p-3 rounded-3 mt-3 shadow-sm">
                                <div class="text-center me-3">
                                    <i class="mdi mdi-check-circle text-primary fs-22"></i>
                                </div>
                                <div class="flex-1">
                                    <h4 class="mb-0 fs-18">Improved Patient Care</h4>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end feathers -->


    <!-- start testimonials -->
    <section class="section bg-white testimonial" id="testimonials">
        <div class="container">

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="text-center header-section mb-5">
                        <span class="text-uppercase fw-semibold text-primary">Testimonials</span>
                        <h1 class="title-heading fw-semibold text-dark mb-3 mt-2">Our Platform's Impact In <br> Their
                            Own Words</h1>
                        <p class="text-muted fs-14 mb-0">Dive into inspiring success stories that showcase how <br> our
                            platform has empowered admin dashboard.</p>
                    </div>
                </div>
            </div>

            <div class="row align-items-center g-3">
                <div class="col-12">
                    <div class="swiper testi-swiper rounded-3 px-1">
                        <div class="swiper-wrapper">

                            <div class="swiper-slide">
                                <div class="p-3 rounded-3 border border-gray">
                                    <p class="mb-3 fs-18 text-dark fst-italic">
                                        "Without a doubt, Spend in stands out as the absolute best.Their exceptional
                                        quality, reliablity, and customer service are unmatched. I have complete....
                                    </p>
                                    <div class="d-flex align-items-center g-4">
                                        <div class="me-2">
                                            <img src="/images/users/user-4.jpg" class="rounded-circle avatar-sm"
                                                 alt="">
                                        </div>
                                        <div class="mt-0">
                                            <h3 class="fs-16 text-primary mb-1">Moritika Kazuki</h3>
                                            <p class="fs-13 fw-medium mb-0">Finance Manager at Mangan</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="p-3 rounded-3 border border-gray">
                                    <p class="mb-3 fs-18 text-dark fst-italic">
                                        I am extremely delighated with the exceptional service provided by NioLand.
                                        Their expert support system, efficient tools, and strategic solutions have
                                        truly....
                                    </p>
                                    <div class="d-flex align-items-center g-4">
                                        <div class="me-2">
                                            <img src="/images/users/user-2.jpg" class="rounded-circle avatar-sm"
                                                 alt="">
                                        </div>
                                        <div class="mt-0">
                                            <h3 class="fs-16 text-primary mb-1">Jimmy Bartney</h3>
                                            <p class="fs-13 fw-medium mb-0">Product Manager At Picko Lab</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="p-3 rounded-3 border border-gray">
                                    <p class="mb-3 fs-18 text-dark fst-italic">
                                        As a satisfied user, I can confidence say that my experience with NioLand has
                                        been outstanding. The service, support, and solutions provided have...
                                    </p>
                                    <div class="d-flex align-items-center g-4">
                                        <div class="me-2">
                                            <img src="/images/users/user-3.jpg" class="rounded-circle avatar-sm"
                                                 alt="">
                                        </div>
                                        <div class="mt-0">
                                            <h3 class="fs-16 text-primary mb-1">Natasha Romanoff</h3>
                                            <p class="fs-13 fw-medium mb-0">Black Widow</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="p-3 rounded-3 border border-gray">
                                    <p class="mb-3 fs-18 text-dark fst-italic">
                                        I've tried many services, but none compare to the excellence provided here!
                                        From start to finish, the team has been attentive, professional.
                                    </p>
                                    <div class="d-flex align-items-center g-4">
                                        <div class="me-2">
                                            <img src="/images/users/user-6.jpg" class="rounded-circle avatar-sm"
                                                 alt="">
                                        </div>
                                        <div class="mt-0">
                                            <h3 class="fs-16 text-primary mb-1">Barbara McIntosh</h3>
                                            <p class="fs-13 fw-medium mb-0">Senior Software Developer</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="g-3 position-relative d-flex justify-content-center align-content-center g-3 mt-4">
                        <div class="next-prev testi-button-prev me-2">
                            <i class="mdi mdi-chevron-left fs-20"></i>
                        </div>
                        <div class="next-prev testi-button-next">
                            <i class="mdi mdi-chevron-right fs-20"></i>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </section>
    <!-- end testimonials -->

    <!-- start FAQs -->
    <section class="section bg-white bg-opacity-50" id="faq">
        <div class="container">

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="text-center header-section mb-5">
                        <span class="text-uppercase fw-semibold text-primary">Questions & Answer</span>
                        <h1 class="title-heading fw-semibold text-dark mb-3 mt-2">Learn more about our platform <br> by
                            user questions</h1>
                        <p class="text-muted fs-14 mb-0">Dive into inspiring success stories that showcase how <br> our
                            platform has empowered admin dashboard.</p>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-6">
                    <div class="p-2">
                        <div class="mb-3">
                            <div class="faq-icon-box">
                                <i data-feather="smile" class="fea icon-md"></i>
                            </div>
                            <h4 class="f-question">Is there a free trail available?</h4>
                            <p class="f-answer mb-4">The admin panel SaaS is a platform that provides administrators
                                with a centralized interface to manage various aspects of their software.</p>
                        </div>

                        <div class="mb-3">
                            <div class="faq-icon-box">
                                <i data-feather="copy" class="fea icon-md"></i>
                            </div>
                            <h4 class="f-question">What features does the admin panel SaaS offer?</h4>
                            <p class="f-answer mb-4">The features may vary depending on the specific platform, but
                                commonly included features are user authentication and authorization.</p>
                        </div>

                        <div class="mb-3">
                            <div class="faq-icon-box">
                                <i data-feather="disc" class="fea icon-md"></i>
                            </div>
                            <h4 class="f-question">How can I sign up for the admin panel SaaS?</h4>
                            <p class="f-answer mb-4">To sign up, visit our website and follow the registration process.
                                You'll need to provide some basic information and choose a subscription plan.</p>
                        </div>

                        <div class="">
                            <div class="faq-icon-box">
                                <i data-feather="user" class="fea icon-md"></i>
                            </div>
                            <h4 class="f-question">What is the Installation?</h4>
                            <p class="f-answer mb-0">The Installation SaaS is a platform designed to streamline the
                                installation process for various software applications or systems.</p>
                        </div>
                    </div>
                </div>


                <div class="col-xl-6">
                    <div class="p-2">
                        <div class="mb-3">
                            <div class="faq-icon-box">
                                <i data-feather="hard-drive" class="fea icon-md"></i>
                            </div>
                            <h4 class="f-question">Is the admin panel customizable?</h4>
                            <p class="f-answer mb-4">Yes, the admin panel SaaS often offers customization options to
                                tailor the interface to your specific requirements. This may include branding
                                customization.</p>
                        </div>

                        <div class="mb-3">
                            <div class="faq-icon-box">
                                <i data-feather="loader" class="fea icon-md"></i>
                            </div>
                            <h4 class="f-question">Is there a mobile app for the admin panel?</h4>
                            <p class="f-answer mb-4">Some admin panel SaaS platforms offer mobile apps or have
                                responsive web designs, allowing you to access the admin panel from mobile devices.</p>
                        </div>

                        <div class="mb-3">
                            <div class="faq-icon-box">
                                <i data-feather="message-square" class="fea icon-md"></i>
                            </div>
                            <h4 class="f-question">Can I integrate the admin panel SaaS with other tools or
                                services?</h4>
                            <p class="f-answer mb-4">Yes, the admin panel SaaS often supports integrations with various
                                third-party tools and services through APIs or pre-built connectors.</p>
                        </div>

                        <div class="">
                            <div class="faq-icon-box">
                                <i data-feather="zap" class="fea icon-md"></i>
                            </div>
                            <h4 class="f-question">How does it work?</h4>
                            <p class="f-answer mb-0">The Buying Product SaaS is a platform that facilitates the purchase
                                process for both buyers and sellers. It provides a centralized marketplace.</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- end FAQs -->

    <!-- start Pricing -->
    <section class="section bg-white" id="plans">
        <div class="container">

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="text-center header-section mb-5">
                        <span class="text-uppercase fw-semibold text-primary">Pricing plans</span>
                        <h1 class="title-heading fw-semibold text-dark mb-3 mt-2">Explore Our Pricing </br> Plan
                            Solutions</h1>
                        <p class="text-muted fs-14 mb-0">Discover pricing options designed to accommodate </br> pratices
                            of all sizes.</p>
                    </div>
                </div>
            </div>

            <!-- Plans -->
            <div class="row justify-content-center my-3">
                <div class="pricing-box col-xl-4 col-md-6">
                    <div class="card card-h-full shadow-sm rounded-3">
                        <div class="d-flex flex-column inner-box card-body p-4">
                            <div class="plan-header flex-shrink-0">
                                <h5 class="plan-title">Freelancer</h5>
                                <p class="plan-subtitle">Neque porro quisquam est, qui dolorem ipsum quia dolor sit
                                    amet.</p>
                            </div>

                            <div class="flex-shrink-0 pb-4 mb-1">
                                <h2 class="month mb-0">
                                    <sup class="fw-semibold"><small>$</small></sup>
                                    <span class="fw-semibold fs-28">24</span>/
                                    <span class="fs-14 text-muted">month</span>
                                </h2>
                            </div>

                            <ul class="flex-grow-1 plan-stats list-unstyled">
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>5 products</li>
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>Up to 1,000
                                    subscribers
                                </li>
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>Basic analytics
                                </li>
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>48-hour support
                                    response time
                                </li>
                            </ul>

                            <div class="flex-shrink-0 text-center">
                                <a href="#"
                                   class="btn btn-outline-primary w-100 rounded-2 fw-medium waves-effect waves-light">Buy
                                    Plan</a>
                            </div>

                        </div>
                    </div> <!-- end Pricing_card -->
                </div> <!-- end col -->

                <div class="pricing-box col-xl-4 col-md-6">
                    <div class="card card-h-full shadow rounded-3">
                        <div class="d-flex flex-column inner-box card-body p-4">
                            <div class="plan-header flex-shrink-0">
                                <h5 class="plan-title text-primary">Startup</h5>
                                <p class="plan-subtitle">Neque porro quisquam est, qui dolorem ipsum quia dolor sit
                                    amet.</p>
                            </div>

                            <div class="flex-shrink-0 pb-4 mb-1">
                                <h2 class="month mb-0">
                                    <sup class="fw-semibold"><small>$</small></sup>
                                    <span class="fw-semibold fs-28">32</span>/
                                    <span class="fs-14 text-muted">month</span>
                                </h2>
                            </div>

                            <ul class="flex-grow-1 plan-stats list-unstyled">
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>25 products</li>
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>Up to 10,000
                                    subscribers
                                </li>
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>Advanced analytics
                                </li>
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>24-hour support
                                    response
                                </li>
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>Marketing
                                    automations
                                </li>
                            </ul>

                            <div class="flex-shrink-0 text-center">
                                <a href="#" class="btn btn-primary w-100 rounded-2">Buy Plan</a>
                            </div>
                        </div>
                    </div> <!-- end Pricing_card -->
                </div> <!-- end col -->

                <div class="pricing-box col-xl-4 col-md-6">
                    <div class="card card-h-full shadow-sm rounded-3">
                        <div class="d-flex flex-column inner-box card-body p-4">

                            <div class="plan-header flex-shrink-0">
                                <h5 class="plan-title">Enterprise</h5>
                                <p class="plan-subtitle">Neque porro quisquam est, qui dolorem ipsum quia dolor sit
                                    amet.</p>
                            </div>

                            <div class="flex-shrink-0 pb-4 mb-1">
                                <h2 class="month mb-0">
                                    <sup class="fw-semibold"><small>$</small></sup>
                                    <span class="fw-semibold fs-28">48</span>/
                                    <span class="fs-14 text-muted">month</span>
                                </h2>
                            </div>

                            <ul class="flex-grow-1 plan-stats list-unstyled">
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>Unlimited products
                                </li>
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>Unlimited
                                    subscribers
                                </li>
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>Advanced analytics
                                </li>
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>Unlimited User</li>
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>1-hour, dedicated
                                    support
                                </li>
                                <li><i data-feather="check" class="check-icon text-primary me-2"></i>Marketing
                                    automations
                                </li>
                            </ul>

                            <div class="flex-shrink-0 text-center">
                                <a href="#"
                                   class="btn btn-outline-primary w-100 rounded-2 fw-medium waves-effect waves-light">Buy
                                    Plan</a>
                            </div>

                        </div>
                    </div> <!-- end Pricing_card -->
                </div> <!-- end col -->
            </div> <!-- end row -->

        </div>
    </section>
    <!-- end Pricing -->


    <!-- start Contact -->
    <section class="section bg-white bg-opacity-50" id="contact">
        <div class="container">

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="text-center header-section mb-5">
                        <span class="text-uppercase fw-semibold text-primary">Contact us</span>
                        <h1 class="title-heading fw-semibold text-dark mb-3 mt-2">We're open to talk to </br> good
                            people.</h1>
                        <p class="text-muted fs-14 mb-0">Discover contact options designed to accommodate </br> pratices
                            of all sizes.</p>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6 col-md-6 mt-4 mt-sm-0 pt-2 pt-sm-0 order-2 order-md-1">
                    <form method="post" onsubmit="return validateForm()">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Your Name <span class="text-danger">*</span></label>
                                    <div class="form-icon position-relative">
                                        <input name="name" id="name" type="text"
                                               class="form-control border-light py-2 bg-light" placeholder="Name :">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Your Email <span class="text-danger">*</span></label>
                                    <div class="form-icon position-relative">
                                        <input name="email" id="email" type="email"
                                               class="form-control border-light py-2 bg-light" placeholder="Email :">
                                    </div>
                                </div>
                            </div><!--end col-->

                            <div class="col-12">
                                <div class="mb-3">
                                    <label class="form-label">Subject</label>
                                    <div class="form-icon position-relative">
                                        <input name="subject" id="subject"
                                               class="form-control border-light py-2 bg-light" placeholder="subject :">
                                    </div>
                                </div>
                            </div><!--end col-->

                            <div class="col-12">
                                <div class="mb-3">
                                    <label class="form-label">Comments <span class="text-danger">*</span></label>
                                    <div class="form-icon position-relative">
                                        <textarea name="comments" id="comments" rows="4"
                                                  class="form-control border-light py-2 bg-light"
                                                  placeholder="Message :"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="">
                                    <button type="submit" id="submit" name="send" class="btn btn-primary">Send Message
                                    </button>
                                </div>
                            </div><!--end col-->
                        </div><!--end row-->
                    </form>
                </div>

                <div class="col-lg-5 offset-lg-1  col-md-6 order-1 order-md-2">
                    <div class="ms-lg-4">
                        <div class="d-flex contact-detail align-items-center">
                            <div class="icon">
                                <i data-feather="mail" class="text-dark"></i>
                            </div>
                            <div class="flex-1 ms-3">
                                <h6 class="fw-medium fs-16 mb-1">123 King Street, London W60 10250</h6>
                                <a href="#" class="fw-medium fs-14 text-primary">see more</a>
                            </div>
                        </div>

                        <div class="d-flex contact-detail align-items-center mt-5">
                            <div class="icon">
                                <i data-feather="phone" class="text-dark"></i>
                            </div>
                            <div class="flex-1 ms-3">
                                <h6 class="fw-medium fs-16 mb-1">contact@example.com</h6>
                                <a href="mailto:contact@example.com" class="fw-medium fs-14 text-primary">say hello</a>
                            </div>
                        </div>

                        <div class="d-flex contact-detail align-items-center mt-5">
                            <div class="icon">
                                <i data-feather="map-pin" class="text-dark"></i>
                            </div>
                            <div class="flex-1 ms-3">
                                <h6 class="fw-medium fs-16 mb-1">(+01) 52534 468 854</h6>
                                <a href="tel:+152534-468-854" class="fw-medium fs-14 text-primary">Call now</a>
                            </div>
                        </div>
                    </div>
                </div><!--end col-->
            </div>
        </div>
    </section>
    <!-- end Pricing -->

    <!-- Start Footer Section -->
    <footer class="footer-section bg-white">

        <div class="container">
            <div class="section-half">
                <div class="row justify-content-center">
                    <div class="col-lg-5 col-md-5">
                        <div class="mb-4">
                            <a href="#"><img src="/images/logo-dark.png" alt="logo" class="card-logo-dark"
                                             alt="logo light" height="26"></a>
                        </div>
                        <p class="mb-3 fs-15 fw-medium footer-text-style">Start using kadso for all your awareness,
                            traffic, and connection needs—it's your all-in-one solution!.</p>

                        <ul class="list-unstyled foot-social-icon mb-0">
                            <li class="list-inline-item">
                                <a href="javascript: void(0);" target="_blank" class="rounded">
                                    <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="16"
                                         height="16" fill="currentColor" viewBox="0 0 16 16">
                                        <path
                                            d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/>
                                    </svg>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="javascript: void(0);" target="_blank" class="rounded">
                                    <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="16"
                                         height="16" fill="currentColor" viewBox="0 0 16 16">
                                        <path
                                            d="M15.545 6.558a9.42 9.42 0 0 1 .139 1.626c0 2.434-.87 4.492-2.384 5.885h.002C11.978 15.292 10.158 16 8 16A8 8 0 1 1 8 0a7.689 7.689 0 0 1 5.352 2.082l-2.284 2.284A4.347 4.347 0 0 0 8 3.166c-2.087 0-3.86 1.408-4.492 3.304a4.792 4.792 0 0 0 0 3.063h.003c.635 1.893 2.405 3.301 4.492 3.301 1.078 0 2.004-.276 2.722-.764h-.003a3.702 3.702 0 0 0 1.599-2.431H8v-3.08h7.545z"/>
                                    </svg>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="javascript: void(0);" target="_blank" class="rounded">
                                    <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="16"
                                         height="16" fill="currentColor" viewBox="0 0 16 16">
                                        <path
                                            d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z"/>
                                    </svg>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="javascript: void(0);" target="_blank" class="rounded ">
                                    <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="16"
                                         height="16" fill="currentColor" viewBox="0 0 16 16">
                                        <path
                                            d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.012 8.012 0 0 0 16 8c0-4.42-3.58-8-8-8z"/>
                                    </svg>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="javascript: void(0);" target="_blank" class="rounded ">
                                    <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="16"
                                         height="16" fill="currentColor" viewBox="0 0 16 16">
                                        <path
                                            d="M3.362 10.11c0 .926-.756 1.681-1.681 1.681S0 11.036 0 10.111C0 9.186.756 8.43 1.68 8.43h1.682v1.68zm.846 0c0-.924.756-1.68 1.681-1.68s1.681.756 1.681 1.68v4.21c0 .924-.756 1.68-1.68 1.68a1.685 1.685 0 0 1-1.682-1.68v-4.21zM5.89 3.362c-.926 0-1.682-.756-1.682-1.681S4.964 0 5.89 0s1.68.756 1.68 1.68v1.682H5.89zm0 .846c.924 0 1.68.756 1.68 1.681S6.814 7.57 5.89 7.57H1.68C.757 7.57 0 6.814 0 5.89c0-.926.756-1.682 1.68-1.682h4.21zm6.749 1.682c0-.926.755-1.682 1.68-1.682.925 0 1.681.756 1.681 1.681s-.756 1.681-1.68 1.681h-1.681V5.89zm-.848 0c0 .924-.755 1.68-1.68 1.68A1.685 1.685 0 0 1 8.43 5.89V1.68C8.43.757 9.186 0 10.11 0c.926 0 1.681.756 1.681 1.68v4.21zm-1.681 6.748c.926 0 1.682.756 1.682 1.681S11.036 16 10.11 16s-1.681-.756-1.681-1.68v-1.682h1.68zm0-.847c-.924 0-1.68-.755-1.68-1.68 0-.925.756-1.681 1.68-1.681h4.21c.924 0 1.68.756 1.68 1.68 0 .926-.756 1.681-1.68 1.681h-4.21z"/>
                                    </svg>
                                </a>
                            </li>
                        </ul><!--end icon-->
                    </div>

                    <div class="col-lg-6 col-md-4 offset-md-1 offset-xxl-1">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 col-12">
                                <div class="mb-3">
                                    <h6 class="fs-18 fw-semibold mb-2">Landings</h6>
                                </div>
                                <ul class="social-text mb-0 ps-0 list-unstyled">
                                    <li class="mb-2"><a href="#">Sass</a></li>
                                    <li class="mb-2"><a href="#">About us</a></li>
                                    <li class="mb-2"><a href="#">Services</a></li>
                                    <li class="mb-2"><a href="#">Finance</a></li>
                                    <li class="mb-2"><a href="#">Digital Agency</a></li>
                                    <li><a href="#">Conference</a></li>
                                </ul>
                            </div>

                            <div class="col-lg-4 col-md-6 col-12">
                                <div class="mb-3">
                                    <h6 class="fs-18 fw-semibold mb-2">Accounts</h6>
                                </div>
                                <ul class="social-text mb-0 ps-0 list-unstyled">
                                    <li class="mb-2"><a href="#">Register</a></li>
                                    <li class="mb-2"><a href="#">Login</a></li>
                                    <li class="mb-2"><a href="#">Forgot Password</a></li>
                                    <li class="mb-2"><a href="#">Reset Password</a></li>
                                    <li><a href="#">Profile</a></li>
                                </ul>
                            </div>

                            <div class="col-lg-4 col-md-6 col-12">
                                <div class="mb-3">
                                    <h6 class="fs-18 fw-semibold mb-2">Resources</h6>
                                </div>
                                <ul class="social-text mb-0 ps-0 list-unstyled">
                                    <li class="mb-2"><a href="#">Terms of Services</a></li>
                                    <li class="mb-2"><a href="#">Privacy Policy</a></li>
                                    <li class="mb-2"><a href="#">Docs</a></li>
                                    <li class="mb-2"><a href="#">Support</a></li>
                                    <li class="mb-2"><a href="#">Changelog</a></li>
                                    <li><a href="#">Community</a></li>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div><!--end row-->
            </div>
        </div>

        <div class="footer-bar border-top border-gray py-3">
            <div class="container">
                <div class="row">
                    <div class="col fs-13 text-muted text-center">
                        <p class="mb-0 fw-medium">&copy;
                            <script>document.write(new Date().getFullYear())</script>
                            - Made with <span class="mdi mdi-heart text-danger"></span> by <a href="#!"
                                                                                              class="text-reset fw-semibold">Zoyothemes</a>
                        </p>
                    </div>
                </div><!--end row-->
            </div><!--end container-->
        </div>
    </footer>
    <!-- End Footer Section -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/landing.init.js','resources/js/pages/swiper.init.js','resources/js/pages/gumshoe.init.js']); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', ['title' => 'Landing'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coderthemes/Desktop/zoyothemes/kadso_laravel/resources/views/landing.blade.php ENDPATH**/ ?>