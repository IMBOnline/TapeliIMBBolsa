<!-- bundle -->
<?php echo $__env->yieldContent('script'); ?>
<!-- App js -->
<?php echo $__env->yieldContent('script-bottom'); ?>
<?php /**PATH C:\Users\pc comp\Desktop\kadso\resources\views/layouts/partials/vendor.blade.php ENDPATH**/ ?>