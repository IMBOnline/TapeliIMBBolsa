<?php $__env->startSection('content'); ?>

<div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
    <div class="flex-grow-1">
        <h4 class="fs-18 fw-semibold m-0">Pricing</h4>
    </div>

    <div class="text-end">
        <ol class="breadcrumb m-0 py-0">
            <li class="breadcrumb-item"><a href="javascript: void(0);">Pages</a></li>
            <li class="breadcrumb-item active">Pricing</li>
        </ol>
    </div>
</div>


<div class="row justify-content-center">
    <div class="col-lg-12">

        <!-- Pricing Title-->
        <div class="text-center">
            <h3 class="mb-2">Pricing Plans</h3>
            <p class="text-muted mb-5">
                We have plans and prices that fit your business perfectly. Make your <br> client site a success with our products.
            </p>
        </div>

        <!-- Plans -->
        <div class="row justify-content-center my-3">
            <div class="pricing-box col-xl-4 col-md-6">
                <div class="card card-h-full">
                    <div class="d-flex flex-column inner-box card-body p-4">
                        <div class="plan-header flex-shrink-0">
                            <h5 class="plan-title">Freelancer</h5>
                            <p class="plan-subtitle">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet.</p>
                        </div>

                        <div class="flex-shrink-0 pb-4 mb-1">
                            <h2 class="month mb-0">
                                <sup class="fw-semibold"><small>$</small></sup> 
                                <span class="fw-semibold fs-28">24</span>/ 
                                <span class="fs-14 text-muted">month</span>
                            </h2>
                        </div>

                        <ul class="flex-grow-1 plan-stats list-unstyled">
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>5 products</li>
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>Up to 1,000 subscribers</li>
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>Basic analytics</li>
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>48-hour support response time</li>
                        </ul>

                        <div class="flex-shrink-0 text-center">
                            <a href="#" class="btn btn-outline-primary w-100 rounded-2 fw-medium">Buy Plan</a>
                        </div>

                    </div>
                </div> <!-- end Pricing_card -->
            </div> <!-- end col -->

            <div class="pricing-box col-xl-4 col-md-6">
                <div class="card card-h-full">
                    <div class="d-flex flex-column inner-box card-body p-4">
                        <div class="plan-header flex-shrink-0">
                            <h5 class="plan-title text-primary">Startup</h5>
                            <p class="plan-subtitle">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet.</p>
                        </div>

                        <div class="flex-shrink-0 pb-4 mb-1">
                            <h2 class="month mb-0">
                                <sup class="fw-semibold"><small>$</small></sup> 
                                <span class="fw-semibold fs-28">32</span>/ 
                                <span class="fs-14 text-muted">month</span>
                            </h2>
                        </div>

                        <ul class="flex-grow-1 plan-stats list-unstyled">
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>25 products</li>
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>Up to 10,000 subscribers</li>
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>Advanced analytics</li>
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>24-hour support response </li>
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>Marketing automations</li>
                        </ul>

                        <div class="flex-shrink-0 text-center">
                            <a href="#" class="btn btn-primary w-100 rounded-2">Buy Plan</a>
                        </div>
                    </div>
                </div> <!-- end Pricing_card -->
            </div> <!-- end col -->

            <div class="pricing-box col-xl-4 col-md-6">
                <div class="card card-h-full">
                    <div class="d-flex flex-column inner-box card-body p-4">

                        <div class="plan-header flex-shrink-0">
                            <h5 class="plan-title">Enterprise</h5>
                            <p class="plan-subtitle">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet.</p>
                        </div>

                        <div class="flex-shrink-0 pb-4 mb-1">
                            <h2 class="month mb-0">
                                <sup class="fw-semibold"><small>$</small></sup> 
                                <span class="fw-semibold fs-28">48</span>/ 
                                <span class="fs-14 text-muted">month</span>
                            </h2>
                        </div>

                        <ul class="flex-grow-1 plan-stats list-unstyled">
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>Unlimited products</li>
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>Unlimited subscribers</li>
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>Advanced analytics</li>
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>Unlimited User</li>
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>1-hour, dedicated support</li>
                            <li><i data-feather="check" class="check-icon text-primary me-2"></i>Marketing automations</li>
                        </ul>

                        <div class="flex-shrink-0 text-center">
                            <a href="#" class="btn btn-outline-primary w-100 rounded-2 fw-medium">Buy Plan</a>
                        </div>

                    </div>
                </div> <!-- end Pricing_card -->
            </div> <!-- end col -->
        </div>
        <!-- end row -->

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vertical', ['title' => 'Pricing'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coderthemes/Desktop/laravel-admin/kadso_laravel/resources/views/utility/pricing.blade.php ENDPATH**/ ?>