<?php $__env->startSection('content'); ?>    

<div class="text-center">
    <div class="mb-4 text-center">
        <a href="<?php echo e(route('any', 'index')); ?>" class="auth-logo">
            <img src="/images/logo-dark.png" alt="logo-dark" class="mx-auto" height="28" />
        </a>
    </div>

    <div class="maintenance-img">
        <img src="/images/svg/500-error.svg" class="img-fluid" alt="coming-soon">
    </div>
    
    <div class="text-center">
        <h3 class="mt-4 fw-semibold text-black text-capitalize">Internal Server Error</h3>
        <p class="text-muted">Our internal server has gone on a uninformed vacation</p>
    </div>

    <a class="btn btn-primary mt-3 me-1" href="<?php echo e(route('any', 'index')); ?>">Back to Home</a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.error', ['title' => 'Error 500'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coderthemes/Krushant/Market/Codecanyon/Bootstrap/Tapeli/Laravel/Tapeli_Laravel_v1.0.0/Tapeli/resources/views/error/error-500.blade.php ENDPATH**/ ?>