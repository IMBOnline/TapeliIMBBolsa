<?php $__env->startSection('content'); ?>
<div class="text-center">
    <div class="mb-4">
        <a href="<?php echo e(route('any', 'index')); ?>" class="auth-logo">
            <img src="/images/logo-dark.png" alt="logo-dark" class="mx-auto" height="28" />
        </a>
    </div>

    <div class="maintenance-img">
        <img src="/images/svg/maintenance.svg" class="img-fluid" alt="maintenance-image">
    </div>

    <div class="text-center">
        <h3 class="mt-4 fw-semibold text-dark text-capitalize">Opps! were under maintenance</h3>
        <p class="text-muted mt-3 mb-4">We sincerely apologize for the inconvenience <br>
            Our site currently undergoing scheduled maintenance and upgrades, but will return shortly.</p>
        
        <h5 class="fs-14">Thank you for your patience</h5>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.error', ['title' => 'Maintenance'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coderthemes/Desktop/laravel-admin/kadso_laravel/resources/views/utility/maintenance.blade.php ENDPATH**/ ?>