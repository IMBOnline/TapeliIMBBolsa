<?php $__env->startSection('content'); ?>
    <div class="mb-0 border-0">
        <div class="p-0">
            <div class="text-center">
                <div class="mb-4">
                    <a href="<?php echo e(route('any', 'index')); ?>" class="auth-logo">
                        <img src="/images/logo-dark.png" alt="logo-dark" class="mx-auto" height="28"/>
                    </a>
                </div>

                <div class="auth-title-section mb-3">
                    <h3 class="text-dark fs-20 fw-medium mb-2">Welcome back</h3>
                    <p class="text-dark text-capitalize fs-14 mb-0">Please enter your details.</p>
                </div>
            </div>
        </div>

        <div class="pt-0">
            <form method="POST" action="<?php echo e(route('login')); ?>" class="my-4">
                <?php echo csrf_field(); ?>
                <?php if(sizeof($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="text-danger mb-3"><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <div class="form-group mb-3">
                    <label for="emailaddress" class="form-label">Email address</label>
                    <input class="form-control" type="email" id="emailaddress" required=""
                           placeholder="Enter your email" name="email" value="demo@user.com">
                </div>

                <div class="form-group mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input class="form-control" type="password" required="" id="password"
                           placeholder="Enter your password" name="password" value="password">
                </div>

                <div class="form-group d-flex mb-3">
                    <div class="col-sm-6">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="checkbox-signin" checked>
                            <label class="form-check-label" for="checkbox-signin">Remember me</label>
                        </div>
                    </div>
                    <div class="col-sm-6 text-end">
                        <a class='text-muted fs-14' href="<?php echo e(route('second', [ 'auth' , 'recoverpw'])); ?>">Forgot
                            password?</a>
                    </div>
                </div>

                <div class="form-group mb-0 row">
                    <div class="col-12">
                        <div class="d-grid">
                            <button class="btn btn-primary" type="submit"> Log In</button>
                        </div>
                    </div>
                </div>
            </form>
            <div class="text-center text-muted">
                <p class="mb-0">Don't have an account ?<a class='text-primary ms-2 fw-medium'
                                                          href="<?php echo e(route('second', [ 'auth' , 'register'])); ?>">Sign
                        Up</a></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', ['title' => 'Login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc comp\Desktop\kadso\resources\views/auth/login.blade.php ENDPATH**/ ?>