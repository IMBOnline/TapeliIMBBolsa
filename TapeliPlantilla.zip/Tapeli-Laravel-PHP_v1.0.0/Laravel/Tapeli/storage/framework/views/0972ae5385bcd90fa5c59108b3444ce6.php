<!DOCTYPE html>
<html lang="en">
<head>

    <?php echo $__env->make('layouts.partials/title-meta', ['title' => $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo $__env->make('layouts.partials/head-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body class="bg-color">

<div class="container-fluid">
    <div class="row vh-100">
        <div class="col-12">
            <div class="p-0">
                <div class="row d-flex align-items-center">
                    <div class="col-md-6 col-xl-6 col-lg-6">
                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                <?php echo $__env->yieldContent('content'); ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-xl-6 col-lg-6 p-0 vh-100 d-flex justify-content-center account-page-bg">
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<!-- END wrapper -->

<?php echo $__env->make('layouts.partials/vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- App js-->
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>

</body>
</html>
<?php /**PATH C:\Users\pc comp\Desktop\kadso\resources\views/layouts/auth.blade.php ENDPATH**/ ?>