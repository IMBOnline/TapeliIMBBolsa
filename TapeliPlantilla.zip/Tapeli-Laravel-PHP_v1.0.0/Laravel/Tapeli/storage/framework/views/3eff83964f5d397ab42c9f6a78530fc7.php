<?php $__env->startSection('content'); ?>
    <div class="mb-0 border-0">
        <div class="p-0">
            <div class="text-center">
                <div class="mb-4">
                    <a href="<?php echo e(route('any', 'index')); ?>" class="auth-logo">
                        <img src="/images/logo-dark.png" alt="logo-dark" class="mx-auto" height="28" />
                    </a>
                </div>

                <div class="auth-title-section mb-3"> 
                    <h3 class="text-dark fs-20 fw-medium mb-2">Email Verification</h3>
                    <p class="text-dark fs-14 mb-0">We will send your a verification code on your email. </p>
                </div>
            </div>
        </div>

        <div class="pt-0">
            <form method="POST" action="<?php echo e(route('login')); ?>" class="my-4">
                <?php echo csrf_field(); ?>
                <?php if(sizeof($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="text-danger mb-3"><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="form-group mb-3">
                    <label for="emailaddress" class="form-label">Email</label>
                    <input class="form-control" type="email" id="emailaddress" required="" placeholder="Enter your email">
                </div>
                
                <div class="form-group mb-0 row">
                    <div class="col-12">
                        <div class="d-grid">
                            <button class="btn btn-primary" type="submit"> Confirm </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', ['title' => 'Email Verification'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coderthemes/Desktop/laravel-admin/kadso_laravel/resources/views/auth/email-verification.blade.php ENDPATH**/ ?>