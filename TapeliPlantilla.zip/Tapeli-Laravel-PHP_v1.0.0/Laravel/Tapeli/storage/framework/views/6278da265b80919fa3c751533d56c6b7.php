<?php $__env->startSection('content'); ?>
    <div class="mb-0 border-0">
        <div class="p-0">
            <div class="text-center">
                <div class="mb-4">
                    <a href="<?php echo e(route('any', 'index')); ?>" class="auth-logo">
                        <img src="/images/logo-dark.png" alt="logo-dark" class="mx-auto" height="28"/>
                    </a>
                </div>
            </div>
        </div>

        <div class="maintenance-img text-center pt-3">
            <img src="/images/svg/logout.svg" height="72" alt="svg-logo">
        </div>

        <div class="text-center auth-title-section">
            <h3 class="text-dark fs-20 fw-medium mb-2">You are Logged Out</h3>
            <p class="text-muted fs-15">Thank you for using kadso admin template</p>
        </div>

        <div class="text-center d-grid">
            <a href="<?php echo e(route('second', [ 'auth' , 'login'])); ?>" class="btn btn-primary mt-3 me-1"> Log In </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', ['title' => 'Logout'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/coderthemes/Desktop/laravel-admin/kadso_laravel/resources/views/auth/logout.blade.php ENDPATH**/ ?>