<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col fs-13 text-muted text-center">
                &copy; <script>document.write(new Date().getFullYear())</script> - Made with <span class="mdi mdi-heart text-danger"></span> by <a href="#!" class="text-reset fw-semibold">Zoyothemes</a> 
            </div>
        </div>
    </div>
</footer>
<!-- end Footer --><?php /**PATH /home/coderthemes/Desktop/laravel-admin/kadso_laravel/resources/views/layouts/partials/footer.blade.php ENDPATH**/ ?>