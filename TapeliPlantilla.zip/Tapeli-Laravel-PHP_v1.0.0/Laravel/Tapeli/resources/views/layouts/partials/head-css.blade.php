@vite(['resources/scss/icons.scss','resources/scss/app.scss'])
