/*
Template Name: Tapeli - Responsive Laravel Admin Dashboard
Author: Zoyothemes
Version: 1.0.0
Website: https://zoyothemes.com/
File: Quill Js
*/

import Quill from "quill";

var quill = new Quill("#quill-editor", {
    theme: "snow",
})
