/*
Template Name: Tapeli - Responsive Laravel Admin Dashboard
Author: Zoyothemes
Version: 1.0.0
Website: https://zoyothemes.com/
File: Gumshoe Js
*/

// 
// Gumshoe Js
//

var spy = new Gumshoe('#navbar-navlist a', {
    offset: 80
});